const gulp = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const cssbeautify = require('gulp-cssbeautify');

gulp.task('dev', function () {
    return gulp.src('scss/*.scss')
        .pipe(sass())
        .pipe(cssbeautify())
        .pipe(gulp.dest('css/'))
});

gulp.task("watch", function() {
 gulp.watch('scss/**/*.scss', gulp.series("dev"));
});

gulp.task("default", gulp.series("watch", gulp.parallel("watch")));

// gulp.task('watch', ['scss'], function () {
//     gulp.watch('public/scss/**/*.scss', ['scss']);
// });
