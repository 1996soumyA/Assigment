(function ($, Drupal) {
  'use strict'
  Drupal.behaviors.mybehavior = {
    attach: function (context, settings) {
      $('.investing-faq-listing .views-row .investing-faq-listing-ques').click(function () {
        $(this).parents('.views-row').toggleClass('is-active');
        $('.investing-faq-listing .views-row .investing-faq-listing-ans').not('.investing-faq-listing .views-row.is-active .investing-faq-listing-ans').slideUp(300);
        $('.investing-faq-listing .views-row.is-active .investing-faq-listing-ans').slideDown(300);
      });
    },
  }
})(jQuery, Drupal)
